function isTextLong (text:string) : boolean
{
    if(text.length >= 10)
    {
        return true;
    }
    return false;
}


function getSquarePerimeter(a:number) :number
{
    return 4*a;
}


