function isTextLong(text) {
    if (text.length >= 10) {
        return true;
    }
    return false;
}
function getSquarePerimeter(a) {
    return 4 * a;
}
function countEven(numbers) {
    var parosErtek = 0;
    if (numbers % 2 == 0) {
        parosErtek++;
    }
    return parosErtek;
}
