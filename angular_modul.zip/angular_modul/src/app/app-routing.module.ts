import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TeruletKeruletComponent } from './terulet-kerulet/terulet-kerulet.component';

const routes: Routes = [
  {path:"terulet-kerulet", component:TeruletKeruletComponent},
  {path:"",redirectTo:"/terulet-kerulet",pathMatch: "full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
