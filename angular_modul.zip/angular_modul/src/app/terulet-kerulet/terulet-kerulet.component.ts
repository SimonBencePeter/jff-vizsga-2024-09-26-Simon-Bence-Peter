import { Component } from '@angular/core';

@Component({
  selector: 'app-terulet-kerulet',
  templateUrl: './terulet-kerulet.component.html',
  styleUrl: './terulet-kerulet.component.css'
})
export class TeruletKeruletComponent {
  aOldal:number=0;
  bOldal:number=0;
  megoldasok: string[] = [];
  szamitas(aOldal:number, bOldal:number){
    if(aOldal >0 && bOldal >0){
    let kerulet = 2*(aOldal+bOldal);
    let terulet =aOldal*bOldal;
    this.megoldasok.push(`A téglalap kerülete:${kerulet} cm területe:${terulet} cm²`);
  }
  else{
    alert("Hibás adat kerület megadásra!")
  }
  }
  }

