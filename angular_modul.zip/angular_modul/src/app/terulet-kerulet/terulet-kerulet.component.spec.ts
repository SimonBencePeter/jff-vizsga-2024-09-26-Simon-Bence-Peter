import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TeruletKeruletComponent } from './terulet-kerulet.component';

describe('TeruletKeruletComponent', () => {
  let component: TeruletKeruletComponent;
  let fixture: ComponentFixture<TeruletKeruletComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TeruletKeruletComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TeruletKeruletComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
